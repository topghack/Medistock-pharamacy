# MediStock local system

MediStock is a local preview of a pharmacy storefront and its staff and admin workspaces. It is a single Flask application backed by one SQLite database, so each portal sees the same products, stock and orders.

## Portals

- **Customer:** browse pharmacist-approved products, manage a cart and saved addresses, place orders, submit M-Pesa references and follow order status.
- **Staff:** claim orders, review M-Pesa references against official business records, progress paid orders through delivery and cancel unpaid orders.
- **Admin:** manage products, categories, inventory, users, delivery assignments, business checkout settings, inventory review, refunds and reports.

## Order lifecycle

Checkout reserves the requested inventory and saves the customer’s prices and delivery details with the order. Unpaid orders remain open until a staff member cancels them. When staff verify a payment, the system records the review and deducts the reserved stock once. Cancelling an unpaid order releases that reservation. Refunds require an administrator record; items are returned to stock only when staff confirm they were physically returned and suitable for resale.

## Local database and run instructions

SQLite stores the local preview in `instance/medistock.db`. On Windows, follow the setup and run steps in [README.md](README.md), or double-click `setup_windows.bat` once and `run_windows.bat` each time you want to start the site.

The project brief confirms MediStock’s location and Send Money number. Checkout remains disabled until an admin configures the business tax treatment and Nairobi delivery fee. The supplied spreadsheet is staged for review because its values have no headers; the software does not guess which numbers are prices or quantities.

## Preview limits

This local preview does not connect to Safaricom, send email or SMS, or support prescription uploads and pharmacist review for prescription orders. Such items are blocked at checkout. Use the system with confirmed catalog data and do not use it for real dispensing or patient-care decisions.
