@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment not found. First run setup_windows.bat.
  pause
  exit /b 1
)
set FLASK_APP=run.py
.venv\Scripts\python.exe -m flask db upgrade
if errorlevel 1 (
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m flask init-business-data
if errorlevel 1 (
  pause
  exit /b 1
)
.venv\Scripts\python.exe run.py
pause
