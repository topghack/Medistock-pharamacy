document.addEventListener('click', (event) => {
  const close = event.target.closest('.flash-close');
  if (close) close.closest('.flash')?.remove();
});

document.addEventListener('submit', (event) => {
  const message = event.target.dataset.confirm;
  if (message && !window.confirm(message)) event.preventDefault();
});
