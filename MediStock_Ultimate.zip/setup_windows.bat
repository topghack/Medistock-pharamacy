@echo off
setlocal
cd /d "%~dp0"
echo Creating the MediStock virtual environment...
where py >nul 2>nul
if not errorlevel 1 py -3 --version >nul 2>nul
if not errorlevel 1 (
  py -3 -m venv .venv
) else (
  where python >nul 2>nul
  if errorlevel 1 goto no_python
  python -m venv .venv
)
if errorlevel 1 goto failed
echo Installing project dependencies...
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
if not exist ".env" .venv\Scripts\python.exe -c "import secrets; open('.env','w',encoding='utf-8').write('MEDISTOCK_SECRET_KEY='+secrets.token_urlsafe(48)+'\nMEDISTOCK_HTTPS=0\n')"
if errorlevel 1 goto failed
set FLASK_APP=run.py
echo Applying database migrations...
.venv\Scripts\python.exe -m flask db upgrade
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m flask init-business-data
if errorlevel 1 goto failed
if exist "data\source\Book1.xlsx" (
  .venv\Scripts\python.exe -m flask stage-inventory "data\source\Book1.xlsx"
  if errorlevel 1 goto failed
)
echo.
echo Create the first admin account now. The password is entered securely.
.venv\Scripts\python.exe -m flask create-admin
if errorlevel 1 goto failed
echo.
echo Setup complete. Run run_windows.bat to start MediStock.
pause
exit /b 0
:no_python
echo Python was not found. Install Python 3.10 or newer and enable the Python launcher or PATH option.
pause
exit /b 1
:failed
echo Setup failed. Make sure Python 3.10 or newer is installed and available as py.
pause
exit /b 1
