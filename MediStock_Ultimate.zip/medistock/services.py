"""Small shared helpers for money, slugs, activity, and notifications."""

import re
import secrets
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP

from flask import request
from flask_login import current_user

from .extensions import db
from .models import AuditLog, Notification, User

CENT = Decimal("0.01")
NAIROBI = timezone(timedelta(hours=3))


def money(value):
    return Decimal(str(value or 0)).quantize(CENT, rounding=ROUND_HALF_UP)


def slugify(value):
    value = re.sub(r"[^a-z0-9]+", "-", (value or "").strip().lower()).strip("-")
    return value or secrets.token_hex(4)


def unique_slug(model, value, current_id=None):
    base = slugify(value)
    slug = base
    suffix = 2
    while model.query.filter(model.slug == slug, model.id != (current_id or 0)).first():
        slug = f"{base}-{suffix}"
        suffix += 1
    return slug


def actor_id():
    return current_user.id if getattr(current_user, "is_authenticated", False) else None


def audit(action, entity_type, entity_id=None, details=None):
    db.session.add(AuditLog(
        actor_id=actor_id(),
        action=action,
        entity_type=entity_type,
        entity_id=None if entity_id is None else str(entity_id),
        details=details,
        ip_address=request.headers.get("X-Forwarded-For", request.remote_addr),
    ))


def notify(title, message, target_url=None, user_id=None, audience_role=None):
    if audience_role:
        recipients = User.query.filter_by(role=audience_role, is_active=True).all()
        for recipient in recipients:
            db.session.add(Notification(user_id=recipient.id, title=title, message=message, target_url=target_url))
        return
    db.session.add(Notification(user_id=user_id, title=title, message=message, target_url=target_url))


def order_number():
    return "MS-" + secrets.token_hex(5).upper()


def nairobi_today():
    return datetime.now(NAIROBI).date()
