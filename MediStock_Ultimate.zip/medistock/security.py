"""Server-side role checks for staff and admin routes."""

from functools import wraps

from flask import abort
from flask_login import current_user, login_required


def role_required(*roles):
    def decorate(view):
        @wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            if not current_user.is_active or current_user.role not in roles:
                abort(403)
            return view(*args, **kwargs)

        return wrapped

    return decorate


admin_required = role_required("admin")
staff_required = role_required("staff", "admin")
