"""Database models for the shared customer, staff and admin system."""

from datetime import datetime, timezone
from decimal import Decimal

from flask_login import UserMixin
from werkzeug.security import check_password_hash, generate_password_hash

from .extensions import db


def utcnow():
    return datetime.now(timezone.utc)


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(254), unique=True, nullable=False, index=True)
    phone = db.Column(db.String(40), nullable=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="customer", index=True)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    is_pharmacist = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)

    addresses = db.relationship("Address", back_populates="user", cascade="all, delete-orphan")
    orders = db.relationship("CustomerOrder", back_populates="customer", foreign_keys="CustomerOrder.customer_id")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Address(db.Model):
    __tablename__ = "addresses"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    label = db.Column(db.String(60), nullable=False, default="Delivery address")
    recipient_name = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(40), nullable=False)
    street_address = db.Column(db.String(240), nullable=False)
    area = db.Column(db.String(120), nullable=False)
    delivery_instructions = db.Column(db.String(500), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)

    user = db.relationship("User", back_populates="addresses")


class Category(db.Model):
    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    slug = db.Column(db.String(120), unique=True, nullable=False)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)

    products = db.relationship("Product", back_populates="category")


class Product(db.Model):
    __tablename__ = "products"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(180), nullable=False, index=True)
    slug = db.Column(db.String(220), unique=True, nullable=False, index=True)
    brand = db.Column(db.String(120), nullable=True)
    strength = db.Column(db.String(80), nullable=True)
    dosage_form = db.Column(db.String(80), nullable=True)
    pack_size = db.Column(db.String(80), nullable=True)
    batch_number = db.Column(db.String(80), nullable=True)
    expiry_date = db.Column(db.Date, nullable=True)
    description = db.Column(db.Text, nullable=True)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id", ondelete="SET NULL"), nullable=True, index=True)
    unit_price = db.Column(db.Numeric(12, 2), nullable=False, default=Decimal("0.00"))
    stock_quantity = db.Column(db.Integer, nullable=False, default=0)
    reserved_quantity = db.Column(db.Integer, nullable=False, default=0)
    reorder_level = db.Column(db.Integer, nullable=False, default=0)
    prescription_required = db.Column(db.Boolean, nullable=False, default=False)
    image_filename = db.Column(db.String(255), nullable=True)
    is_active = db.Column(db.Boolean, nullable=False, default=True, index=True)
    is_approved = db.Column(db.Boolean, nullable=False, default=False, index=True)
    is_featured = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)

    category = db.relationship("Category", back_populates="products")

    @property
    def available_quantity(self):
        return max(0, self.stock_quantity - self.reserved_quantity)

    @property
    def is_expired(self):
        from .services import nairobi_today
        return self.expiry_date is not None and self.expiry_date < nairobi_today()


class CustomerOrder(db.Model):
    __tablename__ = "orders"

    id = db.Column(db.Integer, primary_key=True)
    order_number = db.Column(db.String(24), unique=True, nullable=False, index=True)
    customer_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="RESTRICT"), nullable=False, index=True)
    order_status = db.Column(db.String(32), nullable=False, default="awaiting_payment", index=True)
    payment_status = db.Column(db.String(24), nullable=False, default="unpaid", index=True)
    delivery_status = db.Column(db.String(32), nullable=False, default="awaiting_assignment", index=True)
    recipient_name = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(40), nullable=False)
    delivery_address = db.Column(db.String(300), nullable=False)
    delivery_area = db.Column(db.String(120), nullable=False)
    delivery_instructions = db.Column(db.String(500), nullable=True)
    delivery_zone_name = db.Column(db.String(120), nullable=False)
    subtotal = db.Column(db.Numeric(12, 2), nullable=False)
    tax_rate_percent = db.Column(db.Numeric(6, 3), nullable=False, default=Decimal("0.000"))
    tax_amount = db.Column(db.Numeric(12, 2), nullable=False, default=Decimal("0.00"))
    delivery_fee = db.Column(db.Numeric(12, 2), nullable=False)
    total = db.Column(db.Numeric(12, 2), nullable=False)
    claimed_by_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    rider_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)
    stock_deducted_at = db.Column(db.DateTime(timezone=True), nullable=True)
    reservation_released_at = db.Column(db.DateTime(timezone=True), nullable=True)
    dispatched_at = db.Column(db.DateTime(timezone=True), nullable=True)
    delivered_at = db.Column(db.DateTime(timezone=True), nullable=True)

    customer = db.relationship("User", back_populates="orders", foreign_keys=[customer_id])
    claimed_by = db.relationship("User", foreign_keys=[claimed_by_id])
    rider = db.relationship("User", foreign_keys=[rider_id])
    items = db.relationship("OrderItem", back_populates="order", cascade="all, delete-orphan")
    payments = db.relationship("PaymentSubmission", back_populates="order", cascade="all, delete-orphan", order_by="PaymentSubmission.submitted_at.desc()")


class OrderItem(db.Model):
    __tablename__ = "order_items"

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id", ondelete="SET NULL"), nullable=True)
    product_name = db.Column(db.String(180), nullable=False)
    product_brand = db.Column(db.String(120), nullable=True)
    product_strength = db.Column(db.String(80), nullable=True)
    quantity = db.Column(db.Integer, nullable=False)
    unit_price = db.Column(db.Numeric(12, 2), nullable=False)
    line_total = db.Column(db.Numeric(12, 2), nullable=False)

    order = db.relationship("CustomerOrder", back_populates="items")
    product = db.relationship("Product")


class PaymentSubmission(db.Model):
    __tablename__ = "payment_submissions"

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False, index=True)
    submitted_by_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    reference = db.Column(db.String(80), nullable=False)
    reference_normalized = db.Column(db.String(80), unique=True, nullable=False)
    amount_claimed = db.Column(db.Numeric(12, 2), nullable=False)
    verified_amount = db.Column(db.Numeric(12, 2), nullable=True)
    status = db.Column(db.String(20), nullable=False, default="pending", index=True)
    customer_note = db.Column(db.String(500), nullable=True)
    review_note = db.Column(db.String(500), nullable=True)
    reviewed_by_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    submitted_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)
    reviewed_at = db.Column(db.DateTime(timezone=True), nullable=True)

    order = db.relationship("CustomerOrder", back_populates="payments")
    submitted_by = db.relationship("User", foreign_keys=[submitted_by_id])
    reviewed_by = db.relationship("User", foreign_keys=[reviewed_by_id])
    reviews = db.relationship("PaymentReview", back_populates="submission", cascade="all, delete-orphan")


class PaymentReview(db.Model):
    __tablename__ = "payment_reviews"

    id = db.Column(db.Integer, primary_key=True)
    submission_id = db.Column(db.Integer, db.ForeignKey("payment_submissions.id", ondelete="CASCADE"), nullable=False, index=True)
    staff_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    action = db.Column(db.String(20), nullable=False)
    amount_checked = db.Column(db.Numeric(12, 2), nullable=True)
    note = db.Column(db.String(500), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)

    submission = db.relationship("PaymentSubmission", back_populates="reviews")
    staff = db.relationship("User")


class InventoryMovement(db.Model):
    __tablename__ = "inventory_movements"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id", ondelete="RESTRICT"), nullable=False, index=True)
    actor_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id", ondelete="SET NULL"), nullable=True)
    movement_type = db.Column(db.String(24), nullable=False)
    previous_quantity = db.Column(db.Integer, nullable=False)
    new_quantity = db.Column(db.Integer, nullable=False)
    delta = db.Column(db.Integer, nullable=False)
    reason = db.Column(db.String(300), nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)

    product = db.relationship("Product")
    actor = db.relationship("User")


class PriceHistory(db.Model):
    __tablename__ = "price_history"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id", ondelete="RESTRICT"), nullable=False, index=True)
    actor_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    old_price = db.Column(db.Numeric(12, 2), nullable=False)
    new_price = db.Column(db.Numeric(12, 2), nullable=False)
    reason = db.Column(db.String(300), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)

    product = db.relationship("Product")
    actor = db.relationship("User")


class DeliveryZone(db.Model):
    __tablename__ = "delivery_zones"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    fee = db.Column(db.Numeric(12, 2), nullable=True)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)


class BusinessSetting(db.Model):
    __tablename__ = "business_settings"

    id = db.Column(db.Integer, primary_key=True, default=1)
    business_name = db.Column(db.String(160), nullable=False, default="MediStock")
    location = db.Column(db.String(240), nullable=False, default="3rd Parklands, Jambo Plaza, Nairobi, Kenya")
    mpesa_business_number = db.Column(db.String(40), nullable=False, default="0737395204")
    tax_rate_percent = db.Column(db.Numeric(6, 3), nullable=True)
    tax_confirmed = db.Column(db.Boolean, nullable=False, default=False)
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)


class AuditLog(db.Model):
    __tablename__ = "audit_logs"

    id = db.Column(db.Integer, primary_key=True)
    actor_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    action = db.Column(db.String(100), nullable=False, index=True)
    entity_type = db.Column(db.String(80), nullable=False)
    entity_id = db.Column(db.String(80), nullable=True)
    details = db.Column(db.Text, nullable=True)
    ip_address = db.Column(db.String(64), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)

    actor = db.relationship("User")


class Notification(db.Model):
    __tablename__ = "notifications"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=True, index=True)
    audience_role = db.Column(db.String(20), nullable=True, index=True)
    title = db.Column(db.String(160), nullable=False)
    message = db.Column(db.String(500), nullable=False)
    target_url = db.Column(db.String(300), nullable=True)
    is_read = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)

    user = db.relationship("User")


class InventoryImportRow(db.Model):
    __tablename__ = "inventory_import_rows"

    id = db.Column(db.Integer, primary_key=True)
    source_file = db.Column(db.String(255), nullable=False)
    sheet_name = db.Column(db.String(120), nullable=False)
    source_row = db.Column(db.Integer, nullable=False)
    raw_first_cell = db.Column(db.Text, nullable=True)
    raw_second_cell = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(20), nullable=False, default="needs_review", index=True)
    review_note = db.Column(db.String(500), nullable=True)
    imported_product_id = db.Column(db.Integer, db.ForeignKey("products.id", ondelete="SET NULL"), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)

    imported_product = db.relationship("Product")
