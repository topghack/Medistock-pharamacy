"""Customer, staff and administrator authentication."""

from urllib.parse import urljoin, urlparse

from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from flask_login import current_user, login_required, login_user, logout_user
from sqlalchemy.exc import IntegrityError

from ..extensions import db, limiter
from ..models import User
from ..services import audit

auth_bp = Blueprint("auth", __name__)


def safe_next(target):
    if not target:
        return None
    host_url = urlparse(request.host_url)
    redirect_url = urlparse(urljoin(request.host_url, target))
    if redirect_url.scheme in {"http", "https"} and host_url.netloc == redirect_url.netloc:
        return target
    return None


def destination_for(role):
    if role == "admin":
        return url_for("admin.dashboard")
    if role == "staff":
        return url_for("staff.dashboard")
    return url_for("customer.home")


def login_for_portal(portal):
    if current_user.is_authenticated:
        return redirect(destination_for(current_user.role))
    error = None
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        expected_role = {"customer": "customer", "staff": "staff", "admin": "admin"}[portal]
        allowed = user and user.is_active and user.role == expected_role and user.check_password(password)
        if allowed:
            session.clear()
            login_user(user, remember=False, fresh=True)
            session.permanent = False
            audit("login_success", "user", user.id, f"{portal} portal")
            db.session.commit()
            requested = safe_next(request.args.get("next") or request.form.get("next"))
            return redirect(requested or destination_for(user.role))
        error = "The email or password is incorrect, or this account cannot access this portal."
        audit("login_failed", "user", details=f"Portal: {portal}; email: {email[:120]}")
        db.session.commit()
    return render_template(
        "auth/login.html",
        portal=portal,
        title={"customer": "Sign in", "staff": "Staff sign in", "admin": "Admin sign in"}[portal],
        error=error,
        next_url=request.args.get("next", ""),
    )


@auth_bp.route("/login", methods=["GET", "POST"])
@limiter.limit("5 per minute")
def login():
    return login_for_portal("customer")


@auth_bp.route("/staff/login", methods=["GET", "POST"])
@limiter.limit("5 per minute")
def staff_login():
    return login_for_portal("staff")


@auth_bp.route("/admin/login", methods=["GET", "POST"])
@limiter.limit("5 per minute")
def admin_login():
    return login_for_portal("admin")


@auth_bp.route("/register", methods=["GET", "POST"])
@limiter.limit("5 per minute")
def register():
    if current_user.is_authenticated:
        return redirect(destination_for(current_user.role))
    error = None
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        if not name or not email:
            error = "Enter your name and email address."
        elif len(password) < 12:
            error = "Use a password with at least 12 characters."
        elif password != confirm:
            error = "The passwords do not match."
        elif User.query.filter_by(email=email).first():
            error = "An account already uses this email address."
        else:
            user = User(name=name, email=email, phone=phone or None, role="customer")
            user.set_password(password)
            db.session.add(user)
            audit("customer_registered", "user", details=email)
            try:
                db.session.commit()
            except IntegrityError:
                db.session.rollback()
                error = "An account already uses this email address."
            else:
                login_user(user, remember=False, fresh=True)
                session.permanent = False
                flash("Your account is ready.", "success")
                return redirect(url_for("customer.home"))
    return render_template("auth/register.html", title="Create account", error=error)


@auth_bp.post("/logout")
def logout():
    if current_user.is_authenticated:
        audit("logout", "user", current_user.id)
        db.session.commit()
    logout_user()
    session.clear()
    flash("You have signed out.", "success")
    return redirect(url_for("customer.home"))


@auth_bp.get("/notifications")
@login_required
def notifications():
    from ..models import Notification
    rows = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).all()
    return render_template("shared/notifications.html", title="Updates", notifications=rows)


@auth_bp.post("/notifications/<int:notification_id>/read")
@login_required
def mark_notification_read(notification_id):
    from ..models import Notification
    notification = Notification.query.filter_by(id=notification_id, user_id=current_user.id).first_or_404()
    notification.is_read = True
    db.session.commit()
    target = safe_next(notification.target_url)
    return redirect(target or url_for("auth.notifications"))
