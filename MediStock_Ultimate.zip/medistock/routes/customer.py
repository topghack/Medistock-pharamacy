"""Public catalogue, cart, checkout and customer order views."""

from decimal import Decimal

from flask import Blueprint, flash, redirect, render_template, request, session, url_for, abort
from flask_login import current_user, login_required
from sqlalchemy import update
from sqlalchemy.exc import IntegrityError

from ..extensions import db
from ..models import Address, BusinessSetting, Category, CustomerOrder, DeliveryZone, InventoryMovement, OrderItem, PaymentSubmission, Product, User, utcnow
from ..services import audit, money, nairobi_today, notify, order_number

customer_bp = Blueprint("customer", __name__)


def public_products():
    return Product.query.join(Category).filter(
        Category.is_active.is_(True), Product.is_active.is_(True), Product.is_approved.is_(True),
        (Product.expiry_date.is_(None)) | (Product.expiry_date >= nairobi_today())
    )


def cart_state():
    raw = session.get("cart", {})
    items, subtotal = [], Decimal("0.00")
    for raw_id, raw_qty in raw.items():
        try:
            product_id, quantity = int(raw_id), int(raw_qty)
        except (TypeError, ValueError):
            continue
        product = public_products().filter_by(id=product_id).first()
        if not product or quantity <= 0:
            continue
        line_total = money(product.unit_price * quantity)
        subtotal += line_total
        items.append({"product": product, "quantity": quantity, "line_total": line_total})
    return items, money(subtotal)


@customer_bp.get("/")
def home():
    featured = public_products().filter(Product.is_featured.is_(True)).order_by(Product.name).limit(8).all()
    if not featured:
        featured = public_products().order_by(Product.name).limit(8).all()
    categories = Category.query.filter_by(is_active=True).order_by(Category.name).all()
    return render_template("customer/home.html", title="MediStock | Pharmacy products delivered in Nairobi", featured=featured, categories=categories)


@customer_bp.get("/shop")
def catalogue():
    term = request.args.get("q", "").strip()
    category_slug = request.args.get("category", "").strip()
    query = public_products()
    if term:
        like = f"%{term}%"
        query = query.filter((Product.name.ilike(like)) | (Product.brand.ilike(like)) | (Product.strength.ilike(like)))
    if category_slug:
        query = query.filter(Category.slug == category_slug)
    products = query.order_by(Product.is_featured.desc(), Product.name.asc()).all()
    categories = Category.query.filter_by(is_active=True).order_by(Category.name).all()
    return render_template("customer/catalogue.html", title="Shop pharmacy products", products=products, categories=categories, q=term, selected_category=category_slug)


@customer_bp.get("/products/<slug>")
def product_detail(slug):
    product = public_products().filter_by(slug=slug).first_or_404()
    return render_template("customer/product.html", title=product.name, product=product)


@customer_bp.get("/about")
def about():
    return render_template("customer/info.html", title="About MediStock", page_heading="Your Health, Our Priority", body="MediStock is an online pharmacy based at 3rd Parklands, Jambo Plaza, Nairobi. Customers can browse approved pharmacy products, submit orders and follow payment verification and delivery updates. MediStock uses its own riders for deliveries within Nairobi.")


@customer_bp.get("/privacy")
def privacy():
    return render_template("customer/info.html", title="Privacy", page_heading="Privacy information", body="MediStock uses account, contact and delivery information to manage customer orders and support fulfilment. This local preview does not connect to email, SMS or external payment providers. Privacy terms must be reviewed and approved before public launch.")


@customer_bp.get("/terms")
def terms():
    return render_template("customer/info.html", title="Terms", page_heading="Terms of use", body="Orders remain unpaid until a MediStock staff member verifies the M-Pesa transaction reference against official business records. Product information and terms must be reviewed by qualified pharmacy and business personnel before public launch.")


@customer_bp.route("/cart", methods=["GET", "POST"])
def cart():
    if request.method == "POST":
        updated = {}
        for key, value in request.form.items():
            if not key.startswith("qty_"):
                continue
            try:
                product_id = int(key[4:])
                quantity = int(value or 0)
            except ValueError:
                flash("Enter whole-number quantities.", "error")
                return redirect(url_for("customer.cart"))
            product = public_products().filter_by(id=product_id).first()
            if not product:
                continue
            if quantity < 0 or quantity > product.available_quantity:
                flash(f"The quantity for {product.name} exceeds the available stock.", "error")
                return redirect(url_for("customer.cart"))
            if quantity:
                updated[str(product_id)] = quantity
        session["cart"] = updated
        session.modified = True
        flash("Cart updated.", "success")
        return redirect(url_for("customer.cart"))
    items, subtotal = cart_state()
    return render_template("customer/cart.html", title="Your cart", items=items, subtotal=subtotal)


@customer_bp.post("/cart/add/<int:product_id>")
def add_to_cart(product_id):
    product = public_products().filter_by(id=product_id).first_or_404()
    if product.prescription_required:
        flash("This product requires a prescription workflow that is not enabled in this preview.", "error")
        return redirect(url_for("customer.product_detail", slug=product.slug))
    try:
        quantity = int(request.form.get("quantity", "1"))
    except ValueError:
        quantity = 0
    cart_data = session.get("cart", {})
    current = int(cart_data.get(str(product_id), 0))
    if quantity < 1:
        flash("Choose a quantity of at least one.", "error")
    elif current + quantity > product.available_quantity:
        flash(f"Only {product.available_quantity} unit(s) are available.", "error")
    else:
        cart_data[str(product_id)] = current + quantity
        session["cart"] = cart_data
        session.modified = True
        flash(f"{product.name} added to your cart.", "success")
    return redirect(url_for("customer.product_detail", slug=product.slug))


@customer_bp.post("/cart/remove/<int:product_id>")
def remove_from_cart(product_id):
    cart_data = session.get("cart", {})
    cart_data.pop(str(product_id), None)
    session["cart"] = cart_data
    session.modified = True
    flash("Item removed from your cart.", "success")
    return redirect(url_for("customer.cart"))


@customer_bp.route("/checkout", methods=["GET", "POST"])
@login_required
def checkout():
    items, subtotal = cart_state()
    if not items:
        flash("Add an item to your cart before checkout.", "error")
        return redirect(url_for("customer.catalogue"))
    business = db.session.get(BusinessSetting, 1)
    zones = DeliveryZone.query.filter_by(is_active=True).order_by(DeliveryZone.name).all()
    configured = bool(business and business.tax_confirmed and business.tax_rate_percent is not None)
    error = None
    if request.method == "POST":
        if not configured:
            error = "Checkout is paused until an administrator confirms the tax setting."
        zone_id = request.form.get("delivery_zone_id", type=int)
        zone = db.session.get(DeliveryZone, zone_id) if zone_id else None
        if not zone or not zone.is_active or zone.fee is None:
            error = "Choose a delivery area with a fee configured by MediStock."
        recipient = request.form.get("recipient_name", "").strip()
        phone = request.form.get("phone", "").strip()
        address = request.form.get("delivery_address", "").strip()
        area = request.form.get("delivery_area", "").strip()
        instructions = request.form.get("delivery_instructions", "").strip()
        if not recipient or not phone or not address or not area:
            error = "Complete the recipient, phone, address and area fields."
        if not error:
            try:
                refreshed = []
                for item in items:
                    product = db.session.get(Product, item["product"].id)
                    if not product or not product.is_active or not product.is_approved or product.is_expired:
                        raise ValueError("An item in your cart is no longer available. Please review your cart.")
                    if product.prescription_required:
                        raise ValueError(f"{product.name} requires a prescription workflow that is not configured yet. Please contact the pharmacy before ordering it.")
                    refreshed.append((product, item["quantity"]))
                tax_rate = Decimal(business.tax_rate_percent)
                tax_amount = money(subtotal * tax_rate / Decimal("100"))
                delivery_fee = money(zone.fee)
                total = money(subtotal + tax_amount + delivery_fee)
                order = CustomerOrder(
                    order_number=order_number(), customer_id=current_user.id,
                    order_status="awaiting_payment", payment_status="unpaid", delivery_status="awaiting_assignment",
                    recipient_name=recipient, phone=phone, delivery_address=address, delivery_area=area,
                    delivery_instructions=instructions or None, delivery_zone_name=zone.name,
                    subtotal=subtotal, tax_rate_percent=tax_rate, tax_amount=tax_amount,
                    delivery_fee=delivery_fee, total=total,
                )
                db.session.add(order)
                db.session.flush()
                for product, quantity in refreshed:
                    previous_available = product.available_quantity
                    result = db.session.execute(
                        update(Product)
                        .where(Product.id == product.id, Product.is_active.is_(True), Product.is_approved.is_(True), Product.stock_quantity - Product.reserved_quantity >= quantity)
                        .values(reserved_quantity=Product.reserved_quantity + quantity)
                    )
                    if result.rowcount != 1:
                        raise ValueError(f"Stock changed while checking out. Please review {product.name} and try again.")
                    db.session.add(InventoryMovement(
                        product_id=product.id, order_id=order.id, movement_type="reserved",
                        previous_quantity=previous_available, new_quantity=previous_available - quantity,
                        delta=-quantity, reason=f"Reserved for order {order.order_number}",
                    ))
                    db.session.add(OrderItem(
                        order_id=order.id, product_id=product.id, product_name=product.name,
                        product_brand=product.brand, product_strength=product.strength,
                        quantity=quantity, unit_price=money(product.unit_price),
                        line_total=money(product.unit_price * quantity),
                    ))
                db.session.add(Address(
                    user_id=current_user.id, label="Latest delivery address", recipient_name=recipient,
                    phone=phone, street_address=address, area=area,
                    delivery_instructions=instructions or None,
                ))
                audit("order_created", "order", order.order_number, f"Total {total}; stock reserved")
                notify("New order received", f"Order {order.order_number} is awaiting payment.", "/staff/orders", audience_role="staff")
                notify("Order placed", f"Order {order.order_number} is awaiting payment verification.", url_for("customer.order_detail", order_id=order.id), user_id=current_user.id)
                db.session.commit()
                session["cart"] = {}
                flash("Order placed. Follow the M-Pesa instructions and submit your transaction reference.", "success")
                return redirect(url_for("customer.order_detail", order_id=order.id))
            except (ValueError, IntegrityError) as exc:
                db.session.rollback()
                error = str(exc) if isinstance(exc, ValueError) else "We could not save this order. Please review your cart and try again."
    addresses = Address.query.filter_by(user_id=current_user.id).order_by(Address.created_at.desc()).all()
    return render_template("customer/checkout.html", title="Checkout", items=items, subtotal=subtotal, business=business, zones=zones, configured=configured, error=error, addresses=addresses)


@customer_bp.get("/account/orders")
@login_required
def order_history():
    orders = CustomerOrder.query.filter_by(customer_id=current_user.id).order_by(CustomerOrder.created_at.desc()).all()
    return render_template("customer/orders.html", title="Your orders", orders=orders)


@customer_bp.route("/account/profile", methods=["GET", "POST"])
@login_required
def profile():
    error = None
    if request.method == "POST":
        action = request.form.get("action", "profile")
        if action == "profile":
            name = request.form.get("name", "").strip()
            email = request.form.get("email", "").strip().lower()
            phone = request.form.get("phone", "").strip()
            other = User.query.filter(User.email == email, User.id != current_user.id).first()
            if not name or not email:
                error = "Enter your name and email address."
            elif other:
                error = "Another account uses that email address."
            else:
                current_user.name = name[:120]
                current_user.email = email[:254]
                current_user.phone = phone[:40] or None
                audit("customer_profile_updated", "user", current_user.id)
                db.session.commit()
                flash("Profile updated.", "success")
                return redirect(url_for("customer.profile"))
        elif action == "address":
            recipient = request.form.get("recipient_name", "").strip()
            phone = request.form.get("address_phone", "").strip()
            street = request.form.get("street_address", "").strip()
            area = request.form.get("area", "").strip()
            label = request.form.get("label", "").strip() or "Delivery address"
            if not all((recipient, phone, street, area)):
                error = "Complete the recipient, phone, address and area fields."
            else:
                db.session.add(Address(user_id=current_user.id, label=label[:60], recipient_name=recipient[:120], phone=phone[:40], street_address=street[:240], area=area[:120]))
                db.session.commit()
                flash("Delivery address saved.", "success")
                return redirect(url_for("customer.profile"))
    addresses = Address.query.filter_by(user_id=current_user.id).order_by(Address.created_at.desc()).all()
    return render_template("customer/profile.html", title="Your profile", addresses=addresses, error=error)


@customer_bp.post("/account/addresses/<int:address_id>/delete")
@login_required
def delete_address(address_id):
    address = Address.query.filter_by(id=address_id, user_id=current_user.id).first_or_404()
    db.session.delete(address)
    db.session.commit()
    flash("Delivery address removed.", "success")
    return redirect(url_for("customer.profile"))


@customer_bp.route("/account/orders/<int:order_id>", methods=["GET", "POST"])
@login_required
def order_detail(order_id):
    order = CustomerOrder.query.filter_by(id=order_id, customer_id=current_user.id).first_or_404()
    error = None
    if request.method == "POST":
        if order.payment_status not in {"unpaid", "rejected"} or order.order_status == "cancelled":
            error = "This order is not accepting a new payment reference."
        else:
            reference = request.form.get("reference", "").strip().upper().replace(" ", "")
            note = request.form.get("note", "").strip()
            if len(reference) < 5 or len(reference) > 80 or not reference.isalnum():
                error = "Enter the transaction reference exactly as shown by M-Pesa."
            else:
                submission = PaymentSubmission(
                    order_id=order.id, submitted_by_id=current_user.id,
                    reference=reference, reference_normalized=reference,
                    amount_claimed=order.total, status="pending", customer_note=note or None,
                )
                db.session.add(submission)
                order.payment_status = "under_review"
                order.order_status = "payment_under_review"
                audit("payment_reference_submitted", "order", order.order_number, "Reference queued for staff verification")
                notify("Payment awaiting review", f"Order {order.order_number} has a submitted M-Pesa reference.", f"/staff/orders/{order.id}", audience_role="staff")
                try:
                    db.session.commit()
                except IntegrityError:
                    db.session.rollback()
                    error = "That M-Pesa reference has already been submitted. Check it and contact staff if it is correct."
                else:
                    flash("Reference submitted. Staff will verify it against MediStock’s official payment records.", "success")
                    return redirect(url_for("customer.order_detail", order_id=order.id))
    return render_template("customer/order_detail.html", title=f"Order {order.order_number}", order=order, error=error)


@customer_bp.get("/account/receipt/<int:order_id>")
@login_required
def receipt(order_id):
    order = CustomerOrder.query.filter_by(id=order_id, customer_id=current_user.id).first_or_404()
    if not any(payment.status == "verified" for payment in order.payments):
        abort(404)
    return render_template("customer/receipt.html", title=f"Receipt {order.order_number}", order=order)


