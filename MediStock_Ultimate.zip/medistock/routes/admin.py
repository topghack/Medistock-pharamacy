"""Owner administration for catalogue, stock, staff, orders and reporting."""

import csv
import io
from decimal import Decimal, InvalidOperation
from pathlib import Path
from uuid import uuid4

from flask import Blueprint, abort, current_app, flash, make_response, redirect, render_template, request, url_for
from sqlalchemy import func
from sqlalchemy.exc import IntegrityError
from werkzeug.utils import secure_filename

from ..extensions import db
from ..models import AuditLog, BusinessSetting, Category, CustomerOrder, DeliveryZone, InventoryImportRow, InventoryMovement, OrderItem, PaymentSubmission, PriceHistory, Product, User, utcnow
from ..security import admin_required
from ..services import NAIROBI, audit, money, notify, unique_slug

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")
IMAGE_EXTENSIONS = {"jpg", "jpeg", "png", "webp"}


def parse_money(value, label):
    try:
        amount = Decimal(value).quantize(Decimal("0.01"))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError(f"Enter a valid {label}.")
    if amount < 0:
        raise ValueError(f"{label.title()} cannot be negative.")
    return amount


def upload_product_image(file_storage):
    if not file_storage or not file_storage.filename:
        return None
    filename = secure_filename(file_storage.filename)
    suffix = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if suffix not in IMAGE_EXTENSIONS:
        raise ValueError("Product images must be JPG, PNG or WebP files.")
    destination = Path(current_app.static_folder) / "uploads" / "products"
    destination.mkdir(parents=True, exist_ok=True)
    stored = f"{uuid4().hex}.{suffix}"
    file_storage.save(destination / stored)
    return stored


@admin_bp.get("")
@admin_required
def dashboard():
    order_counts = dict(db.session.query(CustomerOrder.order_status, func.count(CustomerOrder.id)).group_by(CustomerOrder.order_status).all())
    product_count = Product.query.count()
    low_stock = Product.query.filter(Product.is_active.is_(True), Product.stock_quantity - Product.reserved_quantity <= Product.reorder_level).count()
    out_of_stock = Product.query.filter(Product.is_active.is_(True), Product.stock_quantity - Product.reserved_quantity <= 0).count()
    pending_payments = PaymentSubmission.query.filter_by(status="pending").count()
    paid_total = db.session.query(func.coalesce(func.sum(CustomerOrder.total), 0)).filter(CustomerOrder.payment_status == "paid").scalar()
    recent_orders = CustomerOrder.query.order_by(CustomerOrder.created_at.desc()).limit(8).all()
    recent_audit = AuditLog.query.order_by(AuditLog.created_at.desc()).limit(8).all()
    return render_template("admin/dashboard.html", title="Admin overview", order_counts=order_counts, product_count=product_count, low_stock=low_stock, out_of_stock=out_of_stock, pending_payments=pending_payments, paid_total=paid_total, recent_orders=recent_orders, recent_audit=recent_audit)


@admin_bp.get("/products")
@admin_required
def products():
    term = request.args.get("q", "").strip()
    status = request.args.get("status", "all")
    query = Product.query
    if term:
        like = f"%{term}%"
        query = query.filter((Product.name.ilike(like)) | (Product.brand.ilike(like)) | (Product.strength.ilike(like)))
    if status == "live":
        query = query.filter_by(is_active=True, is_approved=True)
    elif status == "draft":
        query = query.filter((Product.is_active.is_(False)) | (Product.is_approved.is_(False)))
    rows = query.order_by(Product.name).all()
    return render_template("admin/products.html", title="Product catalogue", products=rows, q=term, status=status)


@admin_bp.route("/products/new", methods=["GET", "POST"])
@admin_required
def product_new():
    import_row_id = request.values.get("import_row_id", type=int)
    import_row = db.session.get(InventoryImportRow, import_row_id) if import_row_id else None
    categories = Category.query.order_by(Category.name).all()
    error = None
    if request.method == "POST":
        product = Product()
        error = save_product_form(product, categories)
        if not error:
            db.session.add(product)
            db.session.flush()
            if product.stock_quantity:
                db.session.add(InventoryMovement(
                    product_id=product.id, actor_id=current_user.id, movement_type="opening_stock",
                    previous_quantity=0, new_quantity=product.stock_quantity, delta=product.stock_quantity,
                    reason="Opening inventory entered by administrator",
                ))
            if import_row and import_row.status in {"needs_review", "reviewed"}:
                import_row.status = "imported"
                import_row.imported_product_id = product.id
                import_row.review_note = "Product created after administrator reviewed and entered the details."
            audit("product_created", "product", product.id, product.name)
            db.session.commit()
            flash("Product saved. It appears in the customer catalogue only after approval and activation.", "success")
            return redirect(url_for("admin.products"))
    return render_template("admin/product_form.html", title="Add product", product=None, categories=categories, error=error, import_row=import_row)


@admin_bp.route("/products/<int:product_id>/edit", methods=["GET", "POST"])
@admin_required
def product_edit(product_id):
    product = db.session.get(Product, product_id)
    if not product:
        abort(404)
    categories = Category.query.order_by(Category.name).all()
    error = None
    if request.method == "POST":
        old_price = Decimal(product.unit_price)
        error = save_product_form(product, categories)
        if not error:
            if Decimal(product.unit_price) != old_price:
                audit("product_price_changed", "product", product.id, f"{old_price} -> {product.unit_price}")
                db.session.add(PriceHistory(product_id=product.id, actor_id=current_user.id, old_price=old_price, new_price=product.unit_price, reason="Administrator price update"))
            audit("product_updated", "product", product.id, product.name)
            db.session.commit()
            flash("Product updated. Existing orders keep their saved price.", "success")
            return redirect(url_for("admin.products"))
        db.session.rollback()
        product = db.session.get(Product, product_id)
    return render_template("admin/product_form.html", title="Edit product", product=product, categories=categories, error=error, import_row=None)


def save_product_form(product, categories):
    try:
        name = request.form.get("name", "").strip()
        if not name:
            raise ValueError("Product name is required.")
        product.name = name[:180]
        product.slug = unique_slug(Product, name, product.id)
        product.brand = request.form.get("brand", "").strip() or None
        product.strength = request.form.get("strength", "").strip() or None
        product.dosage_form = request.form.get("dosage_form", "").strip() or None
        product.pack_size = request.form.get("pack_size", "").strip() or None
        product.batch_number = request.form.get("batch_number", "").strip() or None
        expiry = request.form.get("expiry_date", "").strip()
        if expiry:
            from datetime import date
            product.expiry_date = date.fromisoformat(expiry)
        else:
            product.expiry_date = None
        product.description = request.form.get("description", "").strip() or None
        product.category_id = request.form.get("category_id", type=int) or None
        if product.category_id and not any(c.id == product.category_id for c in categories):
            raise ValueError("Choose an active catalogue category.")
        product.unit_price = parse_money(request.form.get("unit_price", ""), "selling price")
        try:
            stock_quantity = int(request.form.get("stock_quantity", "0")) if product.id is None else product.stock_quantity
            reorder_level = int(request.form.get("reorder_level", "0"))
        except ValueError:
            raise ValueError("Stock and reorder level must be whole numbers.")
        if stock_quantity < 0 or reorder_level < 0 or stock_quantity < product.reserved_quantity:
            raise ValueError("Stock cannot be negative or lower than the quantity reserved for unpaid orders.")
        product.stock_quantity = stock_quantity
        product.reorder_level = reorder_level
        product.prescription_required = request.form.get("prescription_required") == "on"
        product.is_active = request.form.get("is_active") == "on"
        product.is_approved = request.form.get("is_approved") == "on" if current_user.is_pharmacist else False
        product.is_featured = request.form.get("is_featured") == "on"
        image = upload_product_image(request.files.get("image"))
        if image:
            product.image_filename = image
        return None
    except (ValueError, TypeError) as exc:
        return str(exc)


@admin_bp.post("/products/<int:product_id>/deactivate")
@admin_required
def product_deactivate(product_id):
    product = db.session.get(Product, product_id)
    if not product:
        abort(404)
    product.is_active = not product.is_active
    audit("product_activation_changed", "product", product.id, f"active={product.is_active}")
    db.session.commit()
    flash("Product status updated.", "success")
    return redirect(url_for("admin.products"))


@admin_bp.get("/categories")
@admin_required
def categories():
    rows = Category.query.order_by(Category.name).all()
    return render_template("admin/categories.html", title="Categories", categories=rows)


@admin_bp.post("/categories")
@admin_required
def category_create():
    name = request.form.get("name", "").strip()
    if not name or len(name) > 100:
        flash("Enter a category name up to 100 characters.", "error")
        return redirect(url_for("admin.categories"))
    category = Category(name=name, slug=unique_slug(Category, name))
    db.session.add(category)
    audit("category_created", "category", details=name)
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        flash("A category with that name already exists.", "error")
    else:
        flash("Category added.", "success")
    return redirect(url_for("admin.categories"))


@admin_bp.post("/categories/<int:category_id>/toggle")
@admin_required
def category_toggle(category_id):
    category = db.session.get(Category, category_id)
    if not category:
        abort(404)
    category.is_active = not category.is_active
    audit("category_activation_changed", "category", category.id, f"active={category.is_active}")
    db.session.commit()
    flash("Category status updated.", "success")
    return redirect(url_for("admin.categories"))


@admin_bp.post("/categories/<int:category_id>/update")
@admin_required
def category_update(category_id):
    category = db.session.get(Category, category_id)
    if not category:
        abort(404)
    name = request.form.get("name", "").strip()
    if not name or len(name) > 100:
        flash("Enter a category name up to 100 characters.", "error")
        return redirect(url_for("admin.categories"))
    old = category.name
    category.name = name
    category.slug = unique_slug(Category, name, category.id)
    audit("category_renamed", "category", category.id, f"{old} -> {name}")
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        flash("A category with that name already exists.", "error")
    else:
        flash("Category renamed.", "success")
    return redirect(url_for("admin.categories"))


@admin_bp.route("/products/<int:product_id>/stock", methods=["GET", "POST"])
@admin_required
def stock_adjust(product_id):
    product = db.session.get(Product, product_id)
    if not product:
        abort(404)
    if request.method == "POST":
        try:
            delta = int(request.form.get("quantity_change", ""))
            reason = request.form.get("reason", "").strip()
            if delta == 0 or not reason:
                raise ValueError("Enter a non-zero adjustment and a reason.")
            new_quantity = product.stock_quantity + delta
            if new_quantity < product.reserved_quantity:
                raise ValueError("The new stock level cannot be below units reserved for unpaid orders.")
            previous = product.stock_quantity
            product.stock_quantity = new_quantity
            db.session.add(InventoryMovement(
                product_id=product.id, actor_id=current_user.id, movement_type="adjustment",
                previous_quantity=previous, new_quantity=new_quantity, delta=delta, reason=reason,
            ))
            audit("stock_adjusted", "product", product.id, f"{previous} -> {new_quantity}; {reason}")
            db.session.commit()
            flash("Stock adjustment recorded.", "success")
            return redirect(url_for("admin.products"))
        except ValueError as exc:
            db.session.rollback()
            flash(str(exc), "error")
    movements = InventoryMovement.query.filter_by(product_id=product.id).order_by(InventoryMovement.created_at.desc()).all()
    return render_template("admin/stock.html", title="Adjust stock", product=product, movements=movements)


@admin_bp.route("/staff", methods=["GET", "POST"])
@admin_required
def staff_accounts():
    error = None
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 12:
            error = "Enter name, email and a temporary password with at least 12 characters."
        elif User.query.filter_by(email=email).first():
            error = "An account already uses that email."
        else:
            user = User(name=name, email=email, phone=phone or None, role="staff", is_active=True, is_pharmacist=request.form.get("is_pharmacist") == "on")
            user.set_password(password)
            db.session.add(user)
            audit("staff_account_created", "user", details=email)
            try:
                db.session.commit()
            except IntegrityError:
                db.session.rollback()
                error = "An account already uses that email."
            else:
                flash("Staff account created.", "success")
                return redirect(url_for("admin.staff_accounts"))
    rows = User.query.filter(User.role.in_(["staff", "admin"])).order_by(User.role, User.name).all()
    return render_template("admin/staff.html", title="Staff accounts", staff=rows, error=error)


@admin_bp.post("/staff/<int:user_id>/update")
@admin_required
def staff_update(user_id):
    user = db.session.get(User, user_id)
    if not user or user.role not in {"staff", "admin"}:
        abort(404)
    if user.id == current_user.id and request.form.get("is_active") != "on":
        flash("You cannot deactivate the account you are currently using.", "error")
        return redirect(url_for("admin.staff_accounts"))
    user.name = request.form.get("name", user.name).strip()[:120] or user.name
    user.phone = request.form.get("phone", "").strip() or None
    if user.role == "staff":
        user.is_active = request.form.get("is_active") == "on"
        user.is_pharmacist = request.form.get("is_pharmacist") == "on"
    new_password = request.form.get("new_password", "")
    if new_password:
        if len(new_password) < 12:
            flash("A reset password must have at least 12 characters.", "error")
            return redirect(url_for("admin.staff_accounts"))
        user.set_password(new_password)
        audit("staff_password_reset", "user", user.id)
    audit("staff_account_updated", "user", user.id)
    db.session.commit()
    flash("Account updated.", "success")
    return redirect(url_for("admin.staff_accounts"))


@admin_bp.get("/customers")
@admin_required
def customers():
    term = request.args.get("q", "").strip()
    query = User.query.filter_by(role="customer")
    if term:
        like = f"%{term}%"
        query = query.filter((User.name.ilike(like)) | (User.email.ilike(like)) | (User.phone.ilike(like)))
    rows = query.order_by(User.created_at.desc()).all()
    return render_template("admin/customers.html", title="Customers", customers=rows, q=term)


@admin_bp.post("/customers/<int:user_id>/toggle")
@admin_required
def customer_toggle(user_id):
    user = db.session.get(User, user_id)
    if not user or user.role != "customer":
        abort(404)
    user.is_active = not user.is_active
    audit("customer_account_status_changed", "user", user.id, f"active={user.is_active}")
    db.session.commit()
    flash("Customer account status updated.", "success")
    return redirect(url_for("admin.customers"))


@admin_bp.get("/orders")
@admin_required
def orders():
    status = request.args.get("status", "").strip()
    query = CustomerOrder.query.order_by(CustomerOrder.created_at.desc())
    if status:
        query = query.filter_by(order_status=status)
    rows = query.all()
    staff = User.query.filter_by(role="staff", is_active=True).order_by(User.name).all()
    return render_template("admin/orders.html", title="All orders", orders=rows, selected_status=status, staff=staff)


@admin_bp.post("/orders/<int:order_id>/reassign")
@admin_required
def reassign_order(order_id):
    order = db.session.get(CustomerOrder, order_id)
    if not order:
        abort(404)
    staff_id = request.form.get("staff_id", type=int)
    staff_member = db.session.get(User, staff_id) if staff_id else None
    if staff_member and (staff_member.role != "staff" or not staff_member.is_active):
        flash("Choose an active staff account.", "error")
        return redirect(url_for("admin.orders"))
    old_id = order.claimed_by_id
    order.claimed_by_id = staff_id
    audit("order_reassigned", "order", order.order_number, f"{old_id} -> {staff_id}")
    if staff_id:
        notify("Order assigned", f"Order {order.order_number} has been assigned to you.", f"/staff/orders/{order.id}", user_id=staff_id)
    db.session.commit()
    flash("Order assignment updated.", "success")
    return redirect(url_for("admin.orders"))


@admin_bp.post("/orders/<int:order_id>/refund")
@admin_required
def refund_order(order_id):
    order = db.session.get(CustomerOrder, order_id)
    if not order:
        abort(404)
    action = request.form.get("action", "")
    note = request.form.get("reason", "").strip()
    if not note:
        flash("Record a reason and the official refund reference or review note.", "error")
        return redirect(url_for("staff.order_detail", order_id=order.id))
    if action == "request":
        if order.payment_status != "paid":
            flash("Only a paid order can enter the refund review workflow.", "error")
            return redirect(url_for("staff.order_detail", order_id=order.id))
        order.order_status = "refund_pending"
        order.payment_status = "refund_pending"
        audit("refund_requested", "order", order.order_number, note)
        notify("Refund under review", f"MediStock is reviewing a refund for order {order.order_number}.", f"/account/orders/{order.id}", user_id=order.customer_id)
        db.session.commit()
        flash("Refund review recorded. Stock has not been changed.", "success")
        return redirect(url_for("admin.orders"))
    if action == "complete":
        if order.payment_status != "refund_pending":
            flash("Move this order into refund review before recording a refund.", "error")
            return redirect(url_for("staff.order_detail", order_id=order.id))
        restock = request.form.get("restock_returned_items") == "on"
        if restock and order.stock_deducted_at is None:
            flash("This order has no recorded stock deduction to reverse.", "error")
            return redirect(url_for("staff.order_detail", order_id=order.id))
        if restock:
            for item in order.items:
                if not item.product_id:
                    continue
                product = db.session.get(Product, item.product_id)
                if product:
                    previous = product.stock_quantity
                    product.stock_quantity += item.quantity
                    db.session.add(InventoryMovement(
                        product_id=product.id, order_id=order.id, actor_id=current_user.id,
                        movement_type="refund_restock", previous_quantity=previous,
                        new_quantity=product.stock_quantity, delta=item.quantity,
                        reason=f"Returned stock after refund: {note}",
                    ))
        order.order_status = "refunded"
        order.payment_status = "refunded"
        audit("refund_completed", "order", order.order_number, f"restocked={restock}; {note}")
        notify("Refund recorded", f"A refund was recorded for order {order.order_number}.", f"/account/orders/{order.id}", user_id=order.customer_id)
        db.session.commit()
        flash("Refund recorded. Stock was restored only for items marked as returned and suitable for sale.", "success")
        return redirect(url_for("admin.orders"))
    flash("Choose a valid refund action.", "error")
    return redirect(url_for("staff.order_detail", order_id=order.id))


@admin_bp.get("/deliveries")
@admin_required
def deliveries():
    rows = CustomerOrder.query.filter(CustomerOrder.payment_status == "paid").order_by(CustomerOrder.created_at.desc()).all()
    riders = User.query.filter_by(role="staff", is_active=True).order_by(User.name).all()
    return render_template("admin/deliveries.html", title="Deliveries", orders=rows, riders=riders)


@admin_bp.post("/deliveries/<int:order_id>/assign")
@admin_required
def assign_rider(order_id):
    order = db.session.get(CustomerOrder, order_id)
    rider_id = request.form.get("rider_id", type=int)
    rider = db.session.get(User, rider_id) if rider_id else None
    if not order or (rider and (rider.role != "staff" or not rider.is_active)):
        abort(404)
    old_id = order.rider_id
    order.rider_id = rider_id
    if rider_id:
        order.delivery_status = "assigned"
        notify("Delivery assigned", f"Delivery for {order.order_number} is assigned to you.", f"/staff/orders/{order.id}", user_id=rider_id)
    audit("delivery_reassigned", "order", order.order_number, f"{old_id} -> {rider_id}")
    db.session.commit()
    flash("Delivery assignment updated.", "success")
    return redirect(url_for("admin.deliveries"))


@admin_bp.route("/settings", methods=["GET", "POST"])
@admin_required
def settings():
    business = db.session.get(BusinessSetting, 1)
    if business is None:
        business = BusinessSetting(id=1)
        db.session.add(business)
    zones = DeliveryZone.query.order_by(DeliveryZone.name).all()
    error = None
    if request.method == "POST":
        business.business_name = request.form.get("business_name", "MediStock").strip()[:160] or "MediStock"
        business.location = request.form.get("location", "").strip()[:240]
        business.mpesa_business_number = request.form.get("mpesa_business_number", "").strip()[:40]
        tax_confirmed = request.form.get("tax_confirmed") == "on"
        tax_text = request.form.get("tax_rate_percent", "").strip()
        try:
            if not tax_confirmed:
                business.tax_confirmed = False
                business.tax_rate_percent = None
            else:
                tax = Decimal(tax_text).quantize(Decimal("0.001"))
                if tax < 0 or tax > 100:
                    raise ValueError("Tax rate must be between 0 and 100 percent.")
                business.tax_rate_percent = tax
                business.tax_confirmed = True
            for zone in zones:
                fee_text = request.form.get(f"zone_fee_{zone.id}", "").strip()
                zone.is_active = request.form.get(f"zone_active_{zone.id}") == "on"
                zone.fee = parse_money(fee_text, f"delivery fee for {zone.name}") if fee_text else None
            new_zone = request.form.get("new_zone_name", "").strip()
            if new_zone:
                if DeliveryZone.query.filter_by(name=new_zone).first():
                    raise ValueError("That delivery zone already exists.")
                fee_text = request.form.get("new_zone_fee", "").strip()
                fee = parse_money(fee_text, "delivery fee") if fee_text else None
                db.session.add(DeliveryZone(name=new_zone[:120], fee=fee, is_active=True))
            audit("business_settings_updated", "settings", 1, "Tax confirmation and delivery configuration updated")
            db.session.commit()
            flash("Business settings saved. Checkout will remain closed until tax and a delivery fee are configured.", "success")
            return redirect(url_for("admin.settings"))
        except (ValueError, InvalidOperation) as exc:
            db.session.rollback()
            error = str(exc)
            business = db.session.get(BusinessSetting, 1) or BusinessSetting(id=1)
            zones = DeliveryZone.query.order_by(DeliveryZone.name).all()
    return render_template("admin/settings.html", title="Business settings", business=business, zones=zones, error=error)


@admin_bp.route("/inventory-import", methods=["GET", "POST"])
@admin_required
def inventory_import():
    error = None
    if request.method == "POST":
        source = request.files.get("workbook")
        if not source or not source.filename or not source.filename.lower().endswith(".xlsx"):
            error = "Choose an .xlsx workbook. No rows are published automatically."
        else:
            try:
                from openpyxl import load_workbook
                workbook = load_workbook(source, read_only=True, data_only=True)
                staged = 0
                safe_name = secure_filename(source.filename) or "inventory.xlsx"
                for sheet in workbook.worksheets:
                    for row_index, row in enumerate(sheet.iter_rows(min_row=1, max_col=2, values_only=True), start=1):
                        first, second = row[0], row[1]
                        if first is None and second is None:
                            continue
                        exists = InventoryImportRow.query.filter_by(source_file=safe_name, sheet_name=sheet.title, source_row=row_index).first()
                        if exists:
                            continue
                        db.session.add(InventoryImportRow(
                            source_file=safe_name, sheet_name=sheet.title, source_row=row_index,
                            raw_first_cell="" if first is None else str(first).strip(),
                            raw_second_cell="" if second is None else str(second).strip(),
                            status="needs_review",
                            review_note="Confirm the product name, price and stock from the source before creating a listing.",
                        ))
                        staged += 1
                db.session.commit()
                flash(f"Staged {staged} row(s) for review. Nothing was added to the public catalogue.", "success")
                return redirect(url_for("admin.inventory_import"))
            except Exception:
                db.session.rollback()
                error = "The workbook could not be read. Save it as a standard .xlsx file and try again."
    rows = InventoryImportRow.query.order_by(InventoryImportRow.source_file, InventoryImportRow.sheet_name, InventoryImportRow.source_row).all()
    return render_template("admin/inventory_import.html", title="Inventory import review", rows=rows, error=error)


@admin_bp.post("/inventory-import/<int:row_id>/review")
@admin_required
def inventory_import_review(row_id):
    row = db.session.get(InventoryImportRow, row_id)
    if not row:
        abort(404)
    if row.status == "needs_review":
        row.status = "reviewed"
        row.review_note = request.form.get("review_note", "Reviewed by administrator; product was not imported.").strip()[:500]
        audit("inventory_import_row_reviewed", "inventory_import_row", row.id, row.review_note)
        db.session.commit()
        flash("Source row marked reviewed. Create a product separately with confirmed details.", "success")
    return redirect(url_for("admin.inventory_import"))


@admin_bp.get("/audit")
@admin_required
def audit_log():
    rows = AuditLog.query.order_by(AuditLog.created_at.desc()).all()
    return render_template("admin/audit.html", title="Audit log", rows=rows)


@admin_bp.get("/reports")
@admin_required
def reports():
    period = request.args.get("period", "month")
    from datetime import datetime, time, timedelta, timezone
    local_now = datetime.now(NAIROBI)
    local_today = local_now.date()
    if period == "today":
        start_local = datetime.combine(local_today, time.min, NAIROBI)
    elif period == "week":
        start_local = datetime.combine(local_today - timedelta(days=6), time.min, NAIROBI)
    elif period == "year":
        start_local = datetime.combine(local_today.replace(month=1, day=1), time.min, NAIROBI)
    else:
        start_local = datetime.combine(local_today.replace(day=1), time.min, NAIROBI)
    start = start_local.astimezone(timezone.utc)
    base = CustomerOrder.query.filter(CustomerOrder.created_at >= start)
    revenue = db.session.query(func.coalesce(func.sum(CustomerOrder.total), 0)).filter(CustomerOrder.created_at >= start, CustomerOrder.payment_status == "paid").scalar()
    paid_count = base.filter_by(payment_status="paid").count()
    order_statuses = dict(base.with_entities(CustomerOrder.order_status, func.count(CustomerOrder.id)).group_by(CustomerOrder.order_status).all())
    top_products = db.session.query(
        func.sum(OrderItem.quantity).label("units"),
        OrderItem.product_name.label("product_name"),
        func.sum(OrderItem.line_total).label("revenue"),
    ).join(CustomerOrder, CustomerOrder.id == OrderItem.order_id).filter(CustomerOrder.created_at >= start, CustomerOrder.payment_status == "paid").group_by(OrderItem.product_name).order_by(func.sum(OrderItem.quantity).desc()).limit(10).all()
    return render_template("admin/reports.html", title="Reports", period=period, revenue=revenue, paid_count=paid_count, order_statuses=order_statuses, top_products=top_products)


@admin_bp.get("/reports/orders.csv")
@admin_required
def export_orders():
    rows = CustomerOrder.query.order_by(CustomerOrder.created_at.desc()).all()
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["Order", "Date", "Customer", "Phone", "Subtotal", "Tax", "Delivery", "Total", "Payment", "Order status", "Delivery status"])
    for order in rows:
        writer.writerow([order.order_number, order.created_at.isoformat(), order.customer.name, order.phone, order.subtotal, order.tax_amount, order.delivery_fee, order.total, order.payment_status, order.order_status, order.delivery_status])
    response = make_response(out.getvalue())
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = 'attachment; filename="medistock_orders.csv"'
    audit("orders_csv_exported", "report", details=f"{len(rows)} rows")
    db.session.commit()
    return response
