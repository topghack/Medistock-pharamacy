"""Staff order board, payment review, claims and delivery status."""

from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user
from sqlalchemy import func, update

from ..extensions import db
from ..models import CustomerOrder, InventoryMovement, Notification, OrderItem, PaymentReview, PaymentSubmission, Product, User, utcnow
from ..security import staff_required
from ..services import audit, notify

staff_bp = Blueprint("staff", __name__, url_prefix="/staff")


@staff_bp.get("")
@staff_required
def dashboard():
    counts = dict(db.session.query(CustomerOrder.order_status, func.count(CustomerOrder.id)).group_by(CustomerOrder.order_status).all())
    pending_payments = PaymentSubmission.query.filter_by(status="pending").count()
    assigned = CustomerOrder.query.filter_by(claimed_by_id=current_user.id).filter(CustomerOrder.order_status.notin_(["delivered", "cancelled"])).count()
    recent = CustomerOrder.query.order_by(CustomerOrder.created_at.desc()).limit(8).all()
    approval_count = Product.query.filter_by(is_active=True, is_approved=False).count() if current_user.is_pharmacist else 0
    return render_template("staff/dashboard.html", title="Staff workspace", counts=counts, pending_payments=pending_payments, assigned=assigned, recent=recent, approval_count=approval_count)


@staff_bp.get("/catalogue-review")
@staff_required
def catalogue_review():
    if not current_user.is_pharmacist:
        from flask import abort
        abort(403)
    products = Product.query.filter_by(is_active=True, is_approved=False).order_by(Product.created_at).all()
    return render_template("staff/catalogue_review.html", title="Catalogue review", products=products)


@staff_bp.post("/catalogue-review/<int:product_id>/approve")
@staff_required
def approve_product(product_id):
    if not current_user.is_pharmacist:
        from flask import abort
        abort(403)
    product = db.session.get(Product, product_id)
    if not product:
        from flask import abort
        abort(404)
    if not product.category_id or not product.description or product.unit_price <= 0:
        flash("Add an approved description, category and price before publication.", "error")
        return redirect(url_for("staff.catalogue_review"))
    product.is_approved = True
    audit("product_approved_by_pharmacist", "product", product.id, f"Approved by {current_user.email}")
    notify("Catalogue product approved", f"{product.name} was approved for the customer catalogue.", "/admin/products", audience_role="admin")
    db.session.commit()
    flash("Product approved for the customer catalogue.", "success")
    return redirect(url_for("staff.catalogue_review"))


@staff_bp.get("/orders")
@staff_required
def orders():
    status = request.args.get("status", "").strip()
    query = CustomerOrder.query.order_by(CustomerOrder.created_at.desc())
    if status:
        query = query.filter_by(order_status=status)
    rows = query.all()
    return render_template("staff/orders.html", title="Shared order board", orders=rows, selected_status=status)


@staff_bp.get("/orders/<int:order_id>")
@staff_required
def order_detail(order_id):
    order = db.session.get(CustomerOrder, order_id)
    if not order:
        from flask import abort
        abort(404)
    return render_template("staff/order_detail.html", title=f"Order {order.order_number}", order=order)


@staff_bp.post("/orders/<int:order_id>/claim")
@staff_required
def claim_order(order_id):
    result = db.session.execute(
        update(CustomerOrder)
        .where(CustomerOrder.id == order_id, CustomerOrder.claimed_by_id.is_(None), CustomerOrder.order_status.notin_(["cancelled", "delivered", "refunded"]))
        .values(claimed_by_id=current_user.id, updated_at=utcnow())
    )
    if result.rowcount == 1:
        audit("order_claimed", "order", order_id)
        notify("Order claimed", f"{current_user.name} is handling order #{order_id}.", f"/staff/orders/{order_id}", audience_role="admin")
        flash("You claimed this order.", "success")
    else:
        flash("This order has already been claimed or is no longer available.", "error")
    db.session.commit()
    return redirect(url_for("staff.order_detail", order_id=order_id))


@staff_bp.post("/payments/<int:submission_id>/review")
@staff_required
def review_payment(submission_id):
    submission = db.session.get(PaymentSubmission, submission_id)
    if not submission:
        from flask import abort
        abort(404)
    order = submission.order
    if order.order_status == "cancelled" or order.reservation_released_at is not None:
        flash("This order was cancelled. Its reservation has been released, so payment cannot be verified.", "error")
        return redirect(url_for("staff.order_detail", order_id=order.id))
    if submission.status != "pending":
        flash("This payment submission has already been reviewed.", "error")
        return redirect(url_for("staff.order_detail", order_id=order.id))
    if order.claimed_by_id != current_user.id and current_user.role != "admin":
        flash("Claim this order before reviewing payment. This prevents two staff members handling it at once.", "error")
        return redirect(url_for("staff.order_detail", order_id=order.id))

    action = request.form.get("action", "").strip()
    note = request.form.get("review_note", "").strip()
    amount_text = request.form.get("verified_amount", "").strip()
    verified_amount = None
    if action == "verify":
        try:
            verified_amount = Decimal(amount_text).quantize(Decimal("0.01"))
        except (InvalidOperation, ValueError):
            verified_amount = None
        if verified_amount is None or verified_amount != Decimal(order.total):
            flash("The amount must match the order total exactly. Record the official amount checked, then reject or investigate a mismatch.", "error")
            return redirect(url_for("staff.order_detail", order_id=order.id))
        if not note:
            flash("Add a note confirming the official business record was checked before verifying payment.", "error")
            return redirect(url_for("staff.order_detail", order_id=order.id))
    elif action != "reject":
        flash("Choose verify or reject.", "error")
        return redirect(url_for("staff.order_detail", order_id=order.id))

    try:
        if action == "verify":
            if order.payment_status == "paid" or order.stock_deducted_at is not None:
                raise ValueError("This order has already been paid and its stock deducted.")
            for item in order.items:
                product = db.session.get(Product, item.product_id) if item.product_id else None
                if not product:
                    raise ValueError(f"{item.product_name} is no longer in inventory. Ask an administrator to review this order.")
                if product.is_expired:
                    raise ValueError(f"{item.product_name} is now past its recorded expiry date. Ask an administrator to review the order before confirming payment.")
                before = product.stock_quantity
                result = db.session.execute(
                    update(Product)
                    .where(Product.id == product.id, Product.stock_quantity >= item.quantity, Product.reserved_quantity >= item.quantity)
                    .values(stock_quantity=Product.stock_quantity - item.quantity, reserved_quantity=Product.reserved_quantity - item.quantity)
                )
                if result.rowcount != 1:
                    raise ValueError(f"Reserved stock for {item.product_name} is no longer available. Do not confirm payment until it is resolved.")
                db.session.add(InventoryMovement(
                    product_id=product.id, order_id=order.id, actor_id=current_user.id,
                    movement_type="sale", previous_quantity=before, new_quantity=before - item.quantity,
                    delta=-item.quantity, reason=f"Payment verified for order {order.order_number}",
                ))
            order.stock_deducted_at = utcnow()
            order.payment_status = "paid"
            order.order_status = "processing"
            submission.status = "verified"
            submission.verified_amount = verified_amount
            submission.reviewed_by_id = current_user.id
            submission.reviewed_at = utcnow()
            message = f"Payment verified for order {order.order_number}. Your order is being processed."
            notify("Payment verified", message, f"/account/orders/{order.id}", user_id=order.customer_id)
        else:
            submission.status = "rejected"
            submission.review_note = note or "Payment was not verified against official records."
            submission.reviewed_by_id = current_user.id
            submission.reviewed_at = utcnow()
            order.payment_status = "rejected"
            order.order_status = "awaiting_payment"
            message = f"Payment reference for order {order.order_number} was not verified. Please review the order and submit a valid reference."
            notify("Payment not verified", message, f"/account/orders/{order.id}", user_id=order.customer_id)
        db.session.add(PaymentReview(
            submission_id=submission.id, staff_id=current_user.id,
            action="verify" if action == "verify" else "reject",
            amount_checked=verified_amount, note=note or None,
        ))
        audit("payment_verified" if action == "verify" else "payment_rejected", "payment", submission.id, f"Order {order.order_number}; reference {submission.reference}; {note}")
        db.session.commit()
        flash("Payment verified and stock deducted once." if action == "verify" else "Payment marked as not verified. The reservation remains until the order is cancelled.", "success")
    except ValueError as exc:
        db.session.rollback()
        flash(str(exc), "error")
    return redirect(url_for("staff.order_detail", order_id=order.id))


@staff_bp.post("/orders/<int:order_id>/status")
@staff_required
def update_order_status(order_id):
    order = db.session.get(CustomerOrder, order_id)
    if not order:
        from flask import abort
        abort(404)
    if order.claimed_by_id != current_user.id and current_user.role != "admin":
        flash("Claim this order before updating its progress.", "error")
        return redirect(url_for("staff.order_detail", order_id=order.id))
    target = request.form.get("order_status", "")
    transitions = {
        "processing": {"ready_for_dispatch"},
        "ready_for_dispatch": {"out_for_delivery"},
        "out_for_delivery": {"delivered"},
    }
    if order.payment_status != "paid" or target not in transitions.get(order.order_status, set()):
        flash("That order status change is not allowed.", "error")
        return redirect(url_for("staff.order_detail", order_id=order.id))
    old = order.order_status
    order.order_status = target
    if target == "ready_for_dispatch":
        order.delivery_status = "ready_for_dispatch"
    elif target == "out_for_delivery":
        order.delivery_status = "out_for_delivery"
        order.dispatched_at = utcnow()
    elif target == "delivered":
        order.delivery_status = "delivered"
        order.delivered_at = utcnow()
    audit("order_status_changed", "order", order.order_number, f"{old} -> {target}")
    notify("Order update", f"Your order {order.order_number} is now {target.replace('_', ' ')}.", f"/account/orders/{order.id}", user_id=order.customer_id)
    db.session.commit()
    flash("Order status updated.", "success")
    return redirect(url_for("staff.order_detail", order_id=order.id))


@staff_bp.post("/orders/<int:order_id>/cancel")
@staff_required
def cancel_unpaid_order(order_id):
    order = db.session.get(CustomerOrder, order_id)
    if not order:
        from flask import abort
        abort(404)
    if order.claimed_by_id != current_user.id and current_user.role != "admin":
        flash("Claim this order before cancelling it.", "error")
        return redirect(url_for("staff.order_detail", order_id=order.id))
    if order.order_status in {"cancelled", "delivered", "refunded"} or order.payment_status == "paid":
        flash("Paid or completed orders need the administrator refund workflow. No stock was changed.", "error")
        return redirect(url_for("staff.order_detail", order_id=order.id))
    if order.reservation_released_at is None:
        for item in order.items:
            if item.product_id:
                product = db.session.get(Product, item.product_id)
                if product:
                    before = product.available_quantity
                    result = db.session.execute(
                        update(Product).where(Product.id == product.id, Product.reserved_quantity >= item.quantity)
                        .values(reserved_quantity=Product.reserved_quantity - item.quantity)
                    )
                    if result.rowcount != 1:
                        db.session.rollback()
                        flash(f"Reserved stock for {item.product_name} could not be released safely. Ask an administrator to review this order.", "error")
                        return redirect(url_for("staff.order_detail", order_id=order.id))
                    db.session.add(InventoryMovement(
                        product_id=product.id, order_id=order.id, actor_id=current_user.id,
                        movement_type="reservation_released", previous_quantity=before,
                        new_quantity=before + item.quantity, delta=item.quantity,
                        reason=f"Unpaid order {order.order_number} cancelled by staff",
                    ))
        order.reservation_released_at = utcnow()
    for payment in order.payments:
        if payment.status == "pending":
            payment.status = "closed"
            payment.review_note = "Submission closed when staff cancelled the unpaid order."
            payment.reviewed_by_id = current_user.id
            payment.reviewed_at = utcnow()
            db.session.add(PaymentReview(submission_id=payment.id, staff_id=current_user.id, action="closed", note="Order cancelled before payment verification."))
    if order.payment_status == "under_review":
        order.payment_status = "unpaid"
    order.order_status = "cancelled"
    order.delivery_status = "cancelled"
    audit("unpaid_order_cancelled", "order", order.order_number)
    notify("Order cancelled", f"Your unpaid order {order.order_number} was cancelled by MediStock staff.", f"/account/orders/{order.id}", user_id=order.customer_id)
    db.session.commit()
    flash("Unpaid order cancelled and reserved quantities released.", "success")
    return redirect(url_for("staff.orders"))
