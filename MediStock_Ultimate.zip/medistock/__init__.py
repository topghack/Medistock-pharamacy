"""MediStock application factory."""

import os
import secrets
from pathlib import Path

import click
from dotenv import load_dotenv
from flask import Flask, abort, redirect, render_template, request, session, url_for
from flask_login import current_user
from flask_wtf.csrf import CSRFError
from sqlalchemy import event

from .extensions import csrf, db, limiter, login_manager, migrate

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")


def create_app(test_config=None):
    app = Flask(
        __name__,
        instance_relative_config=True,
        template_folder="templates",
        static_folder=str(ROOT / "static"),
    )
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    uploads = Path(app.instance_path) / "uploads"
    uploads.mkdir(parents=True, exist_ok=True)

    db_path = Path(app.instance_path) / "medistock.db"
    app.config.from_mapping(
        SECRET_KEY=os.getenv("MEDISTOCK_SECRET_KEY") or secrets.token_urlsafe(48),
        SQLALCHEMY_DATABASE_URI=os.getenv("DATABASE_URL") or f"sqlite:///{db_path.as_posix()}",
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        SQLALCHEMY_ENGINE_OPTIONS={"pool_pre_ping": True},
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.getenv("MEDISTOCK_HTTPS", "0") == "1",
        SESSION_REFRESH_EACH_REQUEST=False,
        REMEMBER_COOKIE_HTTPONLY=True,
        REMEMBER_COOKIE_SECURE=os.getenv("MEDISTOCK_HTTPS", "0") == "1",
        WTF_CSRF_TIME_LIMIT=3600,
        MAX_CONTENT_LENGTH=8 * 1024 * 1024,
        UPLOAD_FOLDER=str(uploads),
        RATELIMIT_STORAGE_URI=os.getenv("MEDISTOCK_RATE_LIMIT_STORAGE", "memory://"),
    )
    if test_config:
        app.config.update(test_config)

    db.init_app(app)
    migrate.init_app(app, db, render_as_batch=True)
    login_manager.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)
    if app.config["SQLALCHEMY_DATABASE_URI"].startswith("sqlite:"):
        with app.app_context():
            @event.listens_for(db.engine, "connect")
            def enable_sqlite_safety(connection, _record):
                cursor = connection.cursor()
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.execute("PRAGMA busy_timeout=5000")
                cursor.close()
    login_manager.login_view = "auth.login"

    from . import models  # noqa: F401
    from .routes.auth import auth_bp
    from .routes.customer import customer_bp
    from .routes.staff import staff_bp
    from .routes.admin import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(customer_bp)
    app.register_blueprint(staff_bp)
    app.register_blueprint(admin_bp)

    @login_manager.user_loader
    def load_user(user_id):
        try:
            return db.session.get(models.User, int(user_id))
        except (TypeError, ValueError):
            return None

    @login_manager.unauthorized_handler
    def unauthorized():
        if request.path.startswith("/admin"):
            return redirect(url_for("auth.admin_login", next=request.url))
        if request.path.startswith("/staff"):
            return redirect(url_for("auth.staff_login", next=request.url))
        return redirect(url_for("auth.login", next=request.url))

    @app.context_processor
    def inject_shared_context():
        from .services import nairobi_today
        from .models import BusinessSetting, Category, Notification

        settings = db.session.get(BusinessSetting, 1)
        unread = 0
        if current_user.is_authenticated:
            unread = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
        try:
            cart_count = sum(max(0, int(value)) for value in session.get("cart", {}).values())
        except (TypeError, ValueError, AttributeError):
            cart_count = 0
        nav_categories = Category.query.filter_by(is_active=True).order_by(Category.name).all()
        return {"today": nairobi_today(), "business": settings, "unread_notifications": unread, "nav_categories": nav_categories, "cart_count": cart_count}

    @app.after_request
    def security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        return response

    @app.errorhandler(CSRFError)
    def csrf_error(error):
        return render_template("shared/error.html", title="Form expired", message="This form expired or could not be verified. Please reload the page and try again."), 400

    @app.errorhandler(403)
    def forbidden(_error):
        return render_template("shared/error.html", title="Access denied", message="Your account does not have permission to open this page."), 403

    @app.errorhandler(404)
    def not_found(_error):
        return render_template("shared/error.html", title="Page not found", message="The page may have moved or is no longer available."), 404

    @app.errorhandler(413)
    def upload_too_large(_error):
        return render_template("shared/error.html", title="File too large", message="Choose a file smaller than 8 MB."), 413

    @app.cli.command("create-admin")
    def create_admin_command():
        """Create the first administrator without storing a default password."""
        from .models import User

        name = click.prompt("Administrator name").strip()
        email = click.prompt("Administrator email").strip().lower()
        if User.query.filter_by(email=email).first():
            raise click.ClickException("An account already uses that email address.")
        password = click.prompt("Password (at least 12 characters)", hide_input=True, confirmation_prompt=True)
        if len(password) < 12:
            raise click.ClickException("Use a password with at least 12 characters.")
        is_pharmacist = click.confirm("Is this administrator also a designated pharmacist reviewer?", default=False)
        user = User(name=name, email=email, role="admin", is_pharmacist=is_pharmacist)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        click.echo("Administrator created. Sign in at /admin/login.")

    @app.cli.command("init-business-data")
    def init_business_data_command():
        """Add confirmed business details and starter categories once."""
        from .models import BusinessSetting, Category, DeliveryZone
        from .services import slugify

        if db.session.get(BusinessSetting, 1) is None:
            db.session.add(BusinessSetting(id=1))
        if DeliveryZone.query.filter_by(name="Nairobi").first() is None:
            db.session.add(DeliveryZone(name="Nairobi", fee=None, is_active=True))
        for name in ("Over-the-counter", "Prescription medicines", "Vitamins and supplements", "First aid", "Personal care", "Medical supplies", "Other pharmacy products"):
            if not Category.query.filter_by(name=name).first():
                db.session.add(Category(name=name, slug=slugify(name)))
        db.session.commit()
        click.echo("Confirmed business details and editable starter categories are ready.")

    @app.cli.command("stage-inventory")
    @click.argument("workbook_path", type=click.Path(exists=True, dir_okay=False, path_type=Path))
    def stage_inventory_command(workbook_path):
        """Copy workbook rows to review staging without importing products."""
        from openpyxl import load_workbook
        from .models import InventoryImportRow

        workbook = load_workbook(workbook_path, read_only=True, data_only=True)
        staged = 0
        for sheet in workbook.worksheets:
            for row_index, row in enumerate(sheet.iter_rows(min_row=1, max_col=2, values_only=True), start=1):
                first, second = row[0], row[1]
                if first is None and second is None:
                    continue
                # Setup may be run again after a restart. Keep one review row
                # per source file, sheet, and source row instead of duplicating it.
                if InventoryImportRow.query.filter_by(
                    source_file=workbook_path.name,
                    sheet_name=sheet.title,
                    source_row=row_index,
                ).first():
                    continue
                db.session.add(InventoryImportRow(
                    source_file=workbook_path.name,
                    sheet_name=sheet.title,
                    source_row=row_index,
                    raw_first_cell="" if first is None else str(first).strip(),
                    raw_second_cell="" if second is None else str(second).strip(),
                    status="needs_review",
                    review_note="Source has no headers; confirm product name, price and stock before creating a listing.",
                ))
                staged += 1
        db.session.commit()
        click.echo(f"Staged {staged} raw row(s) for review. No product prices or quantities were guessed.")

    return app
